import java.io.*;
import java.security.*;
import java.security.cert.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;

public class VerifyCertificate {
    public static void main(String[] args) throws CertificateException, FileNotFoundException {
        X509Certificate CA = readCertificate(args[0]);
        X509Certificate user = readCertificate(args[1]);
        verifyCertificate(CA,user);
    }

    public static void verifyCertificate(X509Certificate CA, X509Certificate user) {
        boolean flag = false;
        Date date = null;
        SimpleDateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd");
        try {
            date = dateformat.parse("2022-12-18");
        } catch (ParseException e2) {
            e2.printStackTrace();
        }

        System.out.println(CA.getSubjectX500Principal());
        System.out.println(user.getSubjectX500Principal());
        try {
            CA.verify(CA.getPublicKey());
            CA.checkValidity(date);
            flag = true;
        } catch (CertificateExpiredException | CertificateNotYetValidException e1) {
            System.out.println("Fail.\nCA is not valid.");
        } catch (CertificateException | InvalidKeyException | NoSuchAlgorithmException | NoSuchProviderException | SignatureException e) {
            System.out.println("Fail.\nCA verification failed.");
        }

        try {
            user.verify(CA.getPublicKey());
            user.checkValidity(date);
            if (flag) {
                System.out.println("Pass");
            }
        } catch (CertificateExpiredException | CertificateNotYetValidException e1) {
            System.out.println("Fail.\nCA is not valid.");
        } catch (CertificateException | InvalidKeyException | NoSuchAlgorithmException | NoSuchProviderException | SignatureException e) {
            System.out.println("Fail.\nCA verification failed.");
        }
    }

    public static X509Certificate readCertificate (String certificatePath) throws CertificateException, FileNotFoundException {
        CertificateFactory certificateFac = CertificateFactory.getInstance("X.509");
        FileInputStream certificateFile = new FileInputStream (certificatePath);
        X509Certificate certificate = (X509Certificate) certificateFac.generateCertificate(certificateFile);
        return certificate;
    }
}