import java.io.*;
import java.security.*;
import javax.crypto.*;
import javax.crypto.spec.*;
import java.util.Base64;

public class SessionDecrypter {
    public SecretKey sessionkey;
    public Cipher cipher = null;
    public IvParameterSpec IV = null;

    public SessionDecrypter(byte[] keybytes, byte[] ivbytes) throws InvalidKeyException, InvalidAlgorithmParameterException, NoSuchAlgorithmException, NoSuchPaddingException {
        this.sessionkey = new SecretKeySpec(keybytes,"AES");
        this.IV = new IvParameterSpec(ivbytes);
        this.cipher = Cipher.getInstance("AES/CTR/NoPadding");
        this.cipher.init(Cipher.DECRYPT_MODE, this.sessionkey, this.IV);
    }

    CipherInputStream openCipherInputStream(InputStream input) {
        return new CipherInputStream(input, this.cipher);
    }
}