/*
  Server side of the handshake.
 */

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.net.Socket;
import java.security.*;
import java.security.cert.*;
import java.security.spec.InvalidParameterSpecException;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import java.net.ServerSocket;
import java.io.IOException;

public class ServerHandshake {
    /*
     * The parameters below should be learned by the server
     * through the handshake protocol.
     */

    /* Session host/port, and the corresponding ServerSocket  */
    public ServerSocket sessionSocket;
    public static String sessionHost;
    public static int sessionPort;

    /* The final destination -- simulate handshake with constants */
    public String targetHost;
    public int targetPort;

    /* Security parameters key/iv should also go here. Fill in! */
    public byte[] sessionKey;
    public byte[] sessionIV;
    private X509Certificate clientCertificate;
    /**
     * Run server handshake protocol on a handshake socket. 
     * Here, we simulate the handshake by just creating a new socket
     * with a preassigned port number for the send_Serversession.
     */
    public ServerHandshake(Socket handshakeSocket,String cacert,String usercert) throws IOException, CertificateException, NoSuchAlgorithmException, InvalidKeyException, BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException {
        sessionSocket = new ServerSocket(12345);
        sessionHost = sessionSocket.getInetAddress().getHostName();
        sessionPort = sessionSocket.getLocalPort();

        HandshakeMessage clientHelloMessage = new HandshakeMessage();
        try {
            clientHelloMessage.recv(handshakeSocket);
            if (clientHelloMessage.getParameter("MessageType").equals("ClientHello")) {
                String clientCertificateString = clientHelloMessage.getParameter("Certificate");
                clientCertificate = null;
                byte[] certificateByte1 = Base64.getDecoder().decode(clientCertificateString);
                CertificateFactory certificateFac = CertificateFactory.getInstance("X.509");
                InputStream inputStream = new ByteArrayInputStream(certificateByte1);
                clientCertificate= (X509Certificate) certificateFac.generateCertificate(inputStream);
                X509Certificate caCertificate = VerifyCertificate.readCertificate(cacert);
                VerifyCertificate.verifyCertificate(caCertificate, clientCertificate); ////Ensure the validation
                Logger.log("Client certificate verified.");
            } else {
                throw new Exception();
            }
        } catch (IOException e) {
            e.printStackTrace();
            Logger.log("Error in ClientHello message.");
        } catch (CertificateException e) {
            e.printStackTrace();
            Logger.log("Error in certificate decode.");
        } catch (Exception e) {
            e.printStackTrace();
            Logger.log("Error in certificate verification.");
        }

        String flag = "ServerHello";
        HandshakeMessage serverHelloMessage = new HandshakeMessage();
        try {
            X509Certificate serverCertificate = VerifyCertificate.readCertificate(usercert);
            String serverCertificateString = Base64.getEncoder().encodeToString(serverCertificate.getEncoded());
            serverHelloMessage.putParameter("MessageType","ServerHello");
            serverHelloMessage.putParameter("Certificate",serverCertificateString);
            serverHelloMessage.send(handshakeSocket);
            Logger.log(flag+" message sent.");
        } catch (IOException e) {
            e.printStackTrace();
            Logger.log("Error in ServerHello message.");
        } catch (CertificateEncodingException e) {
            e.printStackTrace();
            Logger.log("Error in certificate file.");
        } catch (CertificateException e) {
            e.printStackTrace();
            Logger.log("Error in certificate encode.");
        }

        HandshakeMessage forwardMessage = new HandshakeMessage();
        try {
            forwardMessage.recv(handshakeSocket);
            if (forwardMessage.getParameter("MessageType").equals("Forward")) {
                targetHost = forwardMessage.getParameter("TargetHost");
                targetPort = Integer.parseInt(forwardMessage.getParameter("TargetPort"));
                Logger.log("Server forward verify succeed.");
            } else {
                throw new Exception();
            }
        } catch (IOException e) {
            e.printStackTrace();
            Logger.log("Error in forwardClient message.");
        } catch (Exception e) {
            e.printStackTrace();
            Logger.log("Error in forwardClient message.");
        }

        HandshakeMessage sessionMessage = new HandshakeMessage();
        sessionMessage.putParameter("MessageType","Session");
        PublicKey clientPublicKey = clientCertificate.getPublicKey();
        try {
            SessionEncrypter sessionEncrypter = new SessionEncrypter(128);
            sessionKey = sessionEncrypter.getKeyBytes();
            sessionIV = sessionEncrypter.getIVBytes();
            byte[] sessionKeyEncrypted =  null;
            Cipher cipher1 = Cipher.getInstance("RSA");
            cipher1.init(Cipher.ENCRYPT_MODE, clientPublicKey);
            sessionKeyEncrypted=cipher1.doFinal(sessionKey);
            byte[] sessionIVEncrypted = HandshakeCrypto.encrypt(sessionIV, clientPublicKey);
            sessionMessage.putParameter("MessageType", "Session");
            sessionMessage.putParameter("SessionKey", Base64.getEncoder().encodeToString(sessionKeyEncrypted));
            sessionMessage.putParameter("SessionIV", Base64.getEncoder().encodeToString(sessionIVEncrypted));
            sessionMessage.putParameter("SessionHost", sessionHost);
            sessionMessage.putParameter("SessionPort", Integer.toString(sessionPort));
            sessionMessage.send(handshakeSocket);
            Logger.log("Session message sent.");
        }  catch (InvalidKeyException | NoSuchAlgorithmException | NoSuchPaddingException
                | InvalidParameterSpecException e) {
            e.printStackTrace();
            Logger.log("Error in Serversession message encryption.");
        }   catch (IllegalBlockSizeException | BadPaddingException e) {
            e.printStackTrace();
            Logger.log("Error in Serversession message encryption.");
        }   catch (IOException e) {
            e.printStackTrace();
            Logger.log("Error in Serversession message.");
        }
    }

    public byte[] getSessionKey(){
        return sessionKey;
    }

    public byte[] getSessionIV(){
        return sessionIV;
    }
}