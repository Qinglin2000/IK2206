import java.io.*;
import java.security.*;
import java.security.spec.InvalidParameterSpecException;
import java.util.Base64;
import javax.crypto.*;
import javax.crypto.spec.*;

public class SessionEncrypter {

    public SecretKey sessionkey=null;
    public Cipher cipher = null;
    public byte[] IVbyte = null;
/*
1.这里IVbyte只能为byte型吗，可不可以是IvParameterSpec
2.为什么cipher.init 里不用调用this.sessionkey.getAESkey()?
*/
    public SessionEncrypter(Integer keylength) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, InvalidParameterSpecException {
       KeyGenerator genkey;
       genkey = KeyGenerator.getInstance("AES");
       SessionKey sv=new SessionKey(keylength);
     //   genkey.init(keylength);
       this.sessionkey = genkey.generateKey();
        this.cipher = Cipher.getInstance("AES/CTR/NoPadding");
        this.IVbyte = cipher.getParameters().getParameterSpec(IvParameterSpec.class).getIV();
        this.cipher.init(Cipher.ENCRYPT_MODE,sv.getAESkey());
    }

    public SessionEncrypter(byte[] keybytes, byte[] ivbytes) throws InvalidKeyException, InvalidAlgorithmParameterException, NoSuchAlgorithmException, NoSuchPaddingException {
        this.sessionkey = new SecretKeySpec(keybytes,"AES");
        this.IVbyte = ivbytes;
        this.cipher = Cipher.getInstance("AES/CTR/NoPadding");
        this.cipher.init(Cipher.ENCRYPT_MODE, this.sessionkey, new IvParameterSpec(ivbytes));
    }

    public CipherOutputStream openCipherOutputStream(OutputStream output) {
        return new CipherOutputStream(output,this.cipher);
    }
    public byte[] getKeyBytes() {
        return this.sessionkey.getEncoded();
    }
    public byte[] getIVBytes() {
        return this.IVbyte;
    }
}