import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

public class SessionKey {

    public SecretKey AESkey;


    public SessionKey(Integer keylength)throws NoSuchAlgorithmException{
        KeyGenerator keygen = KeyGenerator.getInstance("AES");
        keygen.init(keylength);
        this.AESkey = keygen.generateKey();
    }
    public SessionKey(byte[] keybytes){
        this.AESkey = new SecretKeySpec(keybytes, "AES");
    }

    public SecretKey getAESkey() {
        return AESkey;
    }
    public byte[] getKeyBytes(){
        return this.AESkey.getEncoded();
    }

    public String encodeKey() {
        return Base64.getEncoder().withoutPadding().encodeToString(AESkey.getEncoded());
    }
}
