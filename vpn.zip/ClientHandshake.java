import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.net.Socket;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.*;
import java.security.cert.*;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Base64;

public class ClientHandshake {
    /*
     * The parameters below should be learned by the client
     * through the handshake protocol.
     */

    /* Session host/port  */
    public String sessionHost;
    public int sessionPort;
    /* Security parameters key/iv should also go here. Fill in! */
    public byte[] sessionKey;
    public byte[] sessionIV;

    public String getSessionHost() {
        return sessionHost;
    }

    public int getSessionPort() {
        return sessionPort;
    }

    /**
     * Run client handshake protocol on a handshake socket.
     * Here, we do nothing, for now.
     */
    public ClientHandshake(Socket handshakeSocket, String targethost, String targetport, String cacert, String usercert, String ClientPrivateKeyFile) throws IOException, BadPaddingException, NoSuchAlgorithmException, IllegalBlockSizeException, NoSuchPaddingException, InvalidKeyException, InvalidKeySpecException, CertificateException {
        String flag = "ClientHello";
        HandshakeMessage clientHelloMessage = new HandshakeMessage();
        X509Certificate clientCertificate = VerifyCertificate.readCertificate(usercert);
        String clientCertificateString = Base64.getEncoder().encodeToString(clientCertificate.getEncoded());
        clientHelloMessage.putParameter("MessageType", "ClientHello");
        clientHelloMessage.putParameter("Certificate", clientCertificateString);
        clientHelloMessage.send(handshakeSocket);
        Logger.log(flag + " message sent.");

        HandshakeMessage serverHelloMessage = new HandshakeMessage();
        flag = "ServerHello";
        try {
            serverHelloMessage.recv(handshakeSocket);
            if (serverHelloMessage.getParameter("MessageType").equals("ServerHello")) {
                String serverCertificateString = serverHelloMessage.getParameter("Certificate");
                X509Certificate serverCertificate = null;
                byte[] certificateByte = Base64.getDecoder().decode(serverCertificateString);
                CertificateFactory certificateFac = CertificateFactory.getInstance("X.509");
                InputStream inputStream = new ByteArrayInputStream(certificateByte);
                serverCertificate= (X509Certificate) certificateFac.generateCertificate(inputStream);
                X509Certificate caCertificate = VerifyCertificate.readCertificate(cacert);
                VerifyCertificate.verifyCertificate(caCertificate, serverCertificate); //Ensure the validation
                Logger.log("Server certificate verified.");
            } else {
                throw new Exception();
            }
        } catch (IOException e) {
            e.printStackTrace();
            Logger.log("Error in" + flag + "message.");
        } catch (CertificateException e) {
            e.printStackTrace();
            Logger.log("Error in certificate decode.");
        } catch (Exception e) {
            e.printStackTrace();
            Logger.log("Error in certificate verification");
        }

        HandshakeMessage clientforwardMessage = new HandshakeMessage();
        clientforwardMessage.putParameter("MessageType", "Forward");
        clientforwardMessage.putParameter("TargetHost", targethost);
        clientforwardMessage.putParameter("TargetPort", targetport);
        clientforwardMessage.send(handshakeSocket);
        Logger.log("Forward message sent.");

        HandshakeMessage sessionMessage = new HandshakeMessage();
        try {
            sessionMessage.recv(handshakeSocket);
            if (sessionMessage.getParameter("MessageType").equals("Session")) {
                PrivateKey clientPrivateKey = null;
                Path keyfile_path = Paths.get(ClientPrivateKeyFile);
                byte[] privateKey_byte = Files.readAllBytes(keyfile_path);
                PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(privateKey_byte);
                KeyFactory privateKey_fac = KeyFactory.getInstance("RSA");
                clientPrivateKey=privateKey_fac.generatePrivate(keySpec);
                sessionKey = null;
                Cipher cipher1 = Cipher.getInstance("RSA");
                cipher1.init(Cipher.DECRYPT_MODE, clientPrivateKey);
                sessionKey = cipher1.doFinal(Base64.getDecoder().decode(sessionMessage.getParameter("SessionKey")));
                sessionIV = HandshakeCrypto.decrypt(Base64.getDecoder().decode(sessionMessage.getParameter("SessionIV")), clientPrivateKey);
                sessionHost = sessionMessage.getParameter("SessionHost");
                sessionPort = Integer.parseInt(sessionMessage.getParameter("SessionPort"));
                Logger.log("Session message received.");
                Logger.log("Client handshake finished.");
            } else throw new Exception();
        } catch (IOException e) {
            e.printStackTrace();
            Logger.log("Error in sessionClient message.");
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public byte[] getSessionKey(){
        return sessionKey;
    }

    public byte[] getSessionIV(){
        return sessionIV;
    }
}
