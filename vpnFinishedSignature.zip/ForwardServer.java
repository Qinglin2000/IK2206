/**
 * Port forwarding server. Forward data
 * between two TCP ports. Based on Nakov TCP Socket Forward Server 
 * and adapted for IK2206.
 *
 * Original copyright notice below.
 * (c) 2018 Peter Sjodin, KTH
 */

/**
 * Nakov TCP Socket Forward Server - freeware
 * Version 1.0 - March, 2002
 * (c) 2001 by Svetlin Nakov - http://www.nakov.com
 */

import java.lang.Integer;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.io.IOException;
import java.io.FileNotFoundException;

public class ForwardServer
{
    private static final boolean ENABLE_LOGGING = true;
    public static final int DEFAULTHANDSHAKEPORT = 2206;
    public static final String DEFAULTHANDSHAKEHOST = "localhost";
    public static final String PROGRAMNAME = "ForwardServer";
    private static Arguments arguments;

    private ServerHandshake serverHandshake;
    private ServerSocket handshakeListenSocket;

    /**
     * Do handshake negotiation with client to authenticate and learn 
     * target host/port, etc.
     */
    private void doHandshake(Socket handshakeSocket,String cacert,String usercert,String ServerPrivateKeyFile) throws UnknownHostException, IOException, Exception {
        serverHandshake = new ServerHandshake(handshakeSocket,cacert,usercert,ServerPrivateKeyFile);
    }

    /**
     * Starts the forward_Client server - binds on a given port and starts serving
     */
    public void startForwardServer()
    //throws IOException
            throws Exception
    {

        // Bind server on given TCP port
        int port = Integer.parseInt(arguments.get("handshakeport"));
        ServerSocket handshakeListenSocket;
        try {
            handshakeListenSocket = new ServerSocket(port);
        } catch (IOException ioex) {
            throw new IOException("Unable to bind to port " + port + ": " + ioex);
        }

        log("Nakov Forward Server started on TCP port " + handshakeListenSocket.getLocalPort());

        // Accept client connections and process them until stopped
        while(true) {

            Socket handshakeSocket = handshakeListenSocket.accept();
            String clientHostPort = handshakeSocket.getInetAddress().getHostName() + ":" +
                    handshakeSocket.getPort();
            Logger.log("Incoming handshake connection from " + clientHostPort);

            doHandshake(handshakeSocket,arguments.get("cacert"),arguments.get("usercert"),arguments.get("key"));
            handshakeSocket.close();

            //tellUser(serverHandshake.sessionSocket);
            /*
             * Set up port forwarding between an established send_Serversession socket to target host/port.
             *
             */

            ForwardServerClientThread forwardThread;
            forwardThread = new ForwardServerClientThread(serverHandshake.sessionSocket,
                    serverHandshake.targetHost, serverHandshake.targetPort,
                    serverHandshake.getSessionKey(), serverHandshake.getSessionIV());
            forwardThread.start();
        }
    }

    /**
     * Prints given log message on the standard output if logging is enabled,
     * otherwise ignores it
     */
    public void log(String aMessage)
    {
        if (ENABLE_LOGGING)
            System.out.println(aMessage);
    }
/**
    static void usage() {
        String indent = "";
        System.err.println(indent + "Usage: " + PROGRAMNAME + " options");
        System.err.println(indent + "Where options are:");
        indent += "    ";
        System.err.println(indent + "--handshakehost=<hostname>");
        System.err.println(indent + "--handshakeport=<portnumber>");
        System.err.println(indent + "--usercert=<filename>");
        System.err.println(indent + "--cacert=<filename>");
        System.err.println(indent + "--key=<filename>");
    }
*/
    /**
     * Program entry point. Reads settings, starts check-alive thread and
     * the forward_Client server
     */
    public static void main(String[] args)
            throws Exception
    {
        arguments = new Arguments();
        arguments.setDefault("handshakeport", Integer.toString(DEFAULTHANDSHAKEPORT));
        arguments.setDefault("handshakehost", DEFAULTHANDSHAKEHOST);
        arguments.loadArguments(args);

        /*Verify CA and server certificate*/
        try {
            X509Certificate serverCertificate = VerifyCertificate.readCertificate(arguments.get("usercert"));
            X509Certificate caCertificate = VerifyCertificate.readCertificate(arguments.get("cacert"));
            VerifyCertificate.verifyCertificate(caCertificate, serverCertificate);
        } catch (CertificateException | FileNotFoundException e) {
            e.printStackTrace();
        }

        ForwardServer srv = new ForwardServer();
        srv.startForwardServer();
    }

}