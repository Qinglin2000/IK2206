/*
 * Handshake message encoding/decoding and transmission
 * for IK2206 project.
 *
 */

import java.io.IOException;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;

import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.net.InetAddress;
import java.net.Socket;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;

/*
 * A Handshake message is represented as a set of parameters -- <key, value> pairs.
 * Extends Properties class.
 */

public class HandshakeMessage extends Properties {
    byte[] bytes;
    byte[] data;

    /*
     * Get the value of a parameter
     */
    public String getParameter(String param) {
        return this.getProperty(param);
    }

    /*
     * Assign a parameter
     */
    public void putParameter(String param, String value) {
        this.put(param, value);
    }
    public void updateDigest(MessageDigest digest)
    {
        if(bytes != null)digest.update(bytes);
        else digest.update(data);
    }


    /*
     * Send a handshake message out on a socket
     *
     * Use the built-in encoding of Properties as XML:
     *   - Encode the message in XML
     *   - Convert XML to a byte array, and write the byte array to the socket
     *
     * Prepend the byte array with an integer string with the length of the string.
     * The integer string is terminated by a whitespace.
     */
    public void send(Socket socket) throws IOException {
        ByteArrayOutputStream byteOutputStream = new ByteArrayOutputStream();
        String comment = "From " + InetAddress.getLocalHost() + ":" + socket.getLocalPort() +
                " to " + socket.getInetAddress().getHostAddress() + ":" + socket.getPort();
        this.storeToXML(byteOutputStream, comment);
        bytes = byteOutputStream.toByteArray();
        socket.getOutputStream().write(String.format("%d ", bytes.length).getBytes(StandardCharsets.UTF_8));
        socket.getOutputStream().write(bytes);
        socket.getOutputStream().flush();

    }

    /*
     * Receive a handshake message on a socket
     *
     * First read a string with an integer followed by whitespace,
     * which gives the size of the message in bytes. Then read the XML data
     * and convert it to a HandshakeMessage.
     */
    public void recv(Socket socket) throws IOException {
        int length = 0;
        for (int n = socket.getInputStream().read(); !Character.isWhitespace(n); n = socket.getInputStream().read()) {
            length = length * 10 + Character.getNumericValue(n);
        }
        data = new byte[length];
        int nread = 0;
        while (nread < length) {
            nread += socket.getInputStream().read(data, nread, length - nread);
        }
        this.loadFromXML(new ByteArrayInputStream(data));
    }

    //读取时间
    public static String GetTime() throws IOException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String dateStringParse=null;
        try {
            Calendar calendar = Calendar.getInstance();
            Date date = calendar.getTime();
            dateStringParse = sdf.format(date);
            return dateStringParse;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return dateStringParse;

    }

    // int to byte[]
    public static byte[] int2Byte(int i) {
        byte[] result = new byte[4];
        result[0] = (byte) ((i >> 24) & 0xFF);
        result[1] = (byte) ((i >> 16) & 0xFF);
        result[2] = (byte) ((i >> 8) & 0xFF);
        result[3] = (byte) (i & 0xFF);
        return result;
    }
    public static byte[] getSHA256StrJava(String str){
        MessageDigest messageDigest;
        byte[] encodeStr = null;
        try {
            messageDigest = MessageDigest.getInstance("SHA-256");
            messageDigest.update(str.getBytes("UTF-8"));
            encodeStr = messageDigest.digest();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return encodeStr;
    }
}
