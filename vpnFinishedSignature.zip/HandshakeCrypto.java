import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.*;
import java.security.*;
import java.security.cert.*;
import java.security.spec.*;
import javax.crypto.*;

public class HandshakeCrypto {
    private static final String Algorithm_type = "RSA";
    public static byte[] encrypt(byte[] plaintext, Key key) throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException, NoSuchPaddingException {
        Cipher cipher = Cipher.getInstance(Algorithm_type);
        cipher.init(Cipher.ENCRYPT_MODE, key);
        return cipher.doFinal(plaintext);
    }

    public static byte[] decrypt(byte[] ciphertext, Key key) throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException, NoSuchPaddingException {
        Cipher cipher = Cipher.getInstance(Algorithm_type);
        cipher.init(Cipher.DECRYPT_MODE, key);
        return cipher.doFinal(ciphertext);
    }

    public static PublicKey getPublicKeyFromCertFile(String certificatefile) throws FileNotFoundException, CertificateException {
        FileInputStream certfile_input = new FileInputStream(certificatefile);
        CertificateFactory certificate_fac = CertificateFactory.getInstance("X.509");
        X509Certificate certificate = (X509Certificate)certificate_fac.generateCertificate(certfile_input);
        return certificate.getPublicKey();
    }

    public static PrivateKey getPrivateKeyFromKeyFile(String keyfile) throws IOException, NoSuchAlgorithmException, InvalidKeySpecException {
        Path keyfile_path = Paths.get(keyfile);
        byte[] privateKey_byte = Files.readAllBytes(keyfile_path);
        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(privateKey_byte);
        KeyFactory privateKey_fac = KeyFactory.getInstance(Algorithm_type);
        return privateKey_fac.generatePrivate(keySpec);
    }
}
