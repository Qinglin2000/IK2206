import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.security.NoSuchAlgorithmException;

public class SessionKey {
    public SecretKey AESkey;

    public SessionKey(Integer keylength){
        KeyGenerator genkey = null;
        try {
            genkey= KeyGenerator.getInstance("AES");
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        genkey.init(keylength);
        this.AESkey =genkey.generateKey();
    }
    public SessionKey(byte[] keybytes){
        this.AESkey = new SecretKeySpec(keybytes, "AES");
    }
    public SecretKey getSecretKey() {
        return AESkey;
    }
    public byte[] getKeyBytes(){
        return this.AESkey.getEncoded();
    }
}
