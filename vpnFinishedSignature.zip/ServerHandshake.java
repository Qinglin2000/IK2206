/*
  Server side of the handshake.
 */

import java.io.ByteArrayOutputStream;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.cert.*;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.InvalidParameterSpecException;
import java.util.Arrays;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import java.net.ServerSocket;
import java.io.IOException;
import java.util.Date;

public class ServerHandshake {
    /*
     * The parameters below should be learned by the server
     * through the handshake protocol.
     */

    /* Session host/port, and the corresponding ServerSocket  */
    public ServerSocket sessionSocket;
    public static String sessionHost;
    public static int sessionPort;

    /* The final destination -- simulate handshake with constants */
    public String targetHost;
    public int targetPort;

    /* Security parameters key/iv should also go here. Fill in! */
    public byte[] sessionKey;
    public byte[] sessionIV;
    private X509Certificate clientCertificate;
    private String clientCertificateString;
    private String targetPortStr;
    HandshakeMessage clientHelloMessage;
    HandshakeMessage forwardMessage;
    /**
     * Run server handshake protocol on a handshake socket.
     * Here, we simulate the handshake by just creating a new socket
     * with a preassigned port number for the send_Serversession.
     */
    public ServerHandshake(Socket handshakeSocket,String cacert,String usercert,String ServerPrivateKeyFile) throws Exception {
        sessionSocket = new ServerSocket(12345);
        sessionHost = sessionSocket.getInetAddress().getHostName();
        sessionPort = sessionSocket.getLocalPort();
        receive_ClientHello(handshakeSocket,cacert);
        HandshakeMessage serverhellomsg=send_serverHello(handshakeSocket,usercert);
        receive_Forward(handshakeSocket);
        HandshakeMessage sessionmsg=send_Serversession(handshakeSocket);
        receive_ClientFinish(handshakeSocket,usercert);//应该是certificate
        send_ServerFinish(serverhellomsg,sessionmsg,ServerPrivateKeyFile,handshakeSocket);


    }


    public void receive_ClientHello(Socket socket, String caPath) {
        clientHelloMessage = new HandshakeMessage();
        try {
            clientHelloMessage.recv(socket);
            if (clientHelloMessage.getParameter("MessageType").equals("ClientHello")) {
                clientCertificateString = clientHelloMessage.getParameter("Certificate");
                clientCertificate = VerifyCertificate.decodeCertificate(clientCertificateString);
                X509Certificate caCertificate = VerifyCertificate.readCertificate(caPath);
                VerifyCertificate.verifyCertificate(caCertificate, clientCertificate); ////Ensure the validation
                Logger.log("Client certificate verified.");
            } else {
                throw new Exception();
            }
        } catch (IOException e) {
            e.printStackTrace();
            Logger.log("Error in ClientHello message.");
        } catch (CertificateException e) {
            e.printStackTrace();
            Logger.log("Error in certificate decode.");
        } catch (Exception e) {
            e.printStackTrace();
            Logger.log("Error in certificate verification.");
        }
    }

    public HandshakeMessage send_serverHello(Socket socket, String certificatePath) {
        String flag = "ServerHello";
        HandshakeMessage serverHelloMessage = new HandshakeMessage();
        try {
            X509Certificate serverCertificate = VerifyCertificate.readCertificate(certificatePath);
            String serverCertificateString = VerifyCertificate.encodeCertificate(serverCertificate);
            serverHelloMessage.putParameter("MessageType","ServerHello");
            serverHelloMessage.putParameter("Certificate",serverCertificateString);
            serverHelloMessage.send(socket);
            Logger.log(flag+" message sent.");
        } catch (IOException e) {
            e.printStackTrace();
            Logger.log("Error in ServerHello message.");
        } catch (CertificateEncodingException e) {
            e.printStackTrace();
            Logger.log("Error in certificate file.");
        } catch (CertificateException e) {
            e.printStackTrace();
            Logger.log("Error in certificate encode.");
        }
        return serverHelloMessage;
    }

    public void receive_Forward(Socket socket) {
        forwardMessage = new HandshakeMessage();
        try {
            forwardMessage.recv(socket);
            if (forwardMessage.getParameter("MessageType").equals("Forward")) {
                targetHost = forwardMessage.getParameter("TargetHost");
                targetPortStr=forwardMessage.getParameter("TargetPort");
                targetPort = Integer.parseInt(forwardMessage.getParameter("TargetPort"));
                Logger.log("Server forward verify succeed.");
            } else {
                throw new Exception();
            }
        } catch (Exception e) {
            e.printStackTrace();
            Logger.log("Error in forwardClient message.");
        }
    }

    public HandshakeMessage send_Serversession(Socket socket) {
        HandshakeMessage sessionMessage = new HandshakeMessage();
        sessionMessage.putParameter("MessageType","Session");
        PublicKey clientPublicKey = clientCertificate.getPublicKey();
        try {
            SessionEncrypter sessionEncrypter = new SessionEncrypter(128);
            sessionKey = sessionEncrypter.getKeyBytes();
            sessionIV = sessionEncrypter.getIVBytes();
            byte[] sessionKeyEncrypted =  HandshakeCrypto.encrypt(sessionKey, clientPublicKey);
            byte[] sessionIVEncrypted = HandshakeCrypto.encrypt(sessionIV, clientPublicKey);
            sessionMessage.putParameter("MessageType", "Session");
            sessionMessage.putParameter("SessionKey", Base64.getEncoder().encodeToString(sessionKeyEncrypted));
            sessionMessage.putParameter("SessionIV", Base64.getEncoder().encodeToString(sessionIVEncrypted));
            sessionMessage.putParameter("SessionHost", sessionHost);
            sessionMessage.putParameter("SessionPort", Integer.toString(sessionPort));
            sessionMessage.send(socket);
            Logger.log("Session message sent.");
        }  catch (InvalidKeyException | NoSuchAlgorithmException | NoSuchPaddingException | InvalidParameterSpecException | IllegalBlockSizeException | BadPaddingException e) {
            e.printStackTrace();
            Logger.log("Error in Serversession message encryption.");
        } catch (IOException e) {
            e.printStackTrace();
            Logger.log("Error in Serversession message.");
        }
        return sessionMessage;
    }
    /*receive CilentFinish message
    ForwardServer verifies the ClientFinish message
    by comparing the received hash with the hash of the messages ForwardServer has received.
    It also decrypts the timestamp with the public key of the ForwardClient,
    and checks that the timesstamp is the current time (plus/minus one second to allow for some delay and clock skew).
     */
    public void receive_ClientFinish(Socket socket,String certificatefile) throws Exception {
        HandshakeMessage clientFinishMessage = new HandshakeMessage();
        int hashcompare=0;
        int timestampcompare=1;
        clientFinishMessage.recv(socket);
        Logger.log("ClientFinishMessage received.");
        PublicKey clientPublickey = clientCertificate.getPublicKey();
        if (!clientFinishMessage.getParameter("MessageType").equals("ClientFinished")) {
            throw new Exception("Did not receive ClientFinishedMessage");
         }
         byte[] hashbytesDecrypted = HandshakeCrypto.decrypt(Base64.getDecoder().decode(clientFinishMessage.getParameter("Signature")),clientPublickey);
         byte[] timebyteDecrypted =  HandshakeCrypto.decrypt(Base64.getDecoder().decode(clientFinishMessage.getParameter("TimeStamp")),clientPublickey);
        MessageDigest clientDigest = MessageDigest.getInstance("SHA-256") ;
        clientHelloMessage.updateDigest(clientDigest);
        forwardMessage.updateDigest(clientDigest);
         String clienthellomsgType="ClientHello";
         String clienthellomsgCertificate= clientCertificateString;
         String clientforwardmsgType ="Forward";
         String clientforwardmsgTargetHost = targetHost;
         String clientforwardmsgTargetPort = targetPortStr;

        /* compare hash and timestamp */
         ByteArrayOutputStream byteOutputStream = new ByteArrayOutputStream();
         StringBuilder clmsgbulider = new StringBuilder().append(clienthellomsgType).append(clienthellomsgCertificate).append(clientforwardmsgType).append(clientforwardmsgTargetHost).append(clientforwardmsgTargetPort);
         String clmsg = clmsgbulider.toString();
         clientFinishMessage.storeToXML(byteOutputStream, clmsg);
         byte[] bytes = byteOutputStream.toByteArray();
         byte[] hashbytes= HandshakeMessage.getSHA256StrJava(bytes.toString());    //hash parameters
         //get received time
         String timeStampReceived = new String(timebyteDecrypted,"UTF-8");
         int timeStampReceivedlast = Integer.parseInt(timeStampReceived.substring(timeStampReceived.length()-1));
         //get now time
         String nowtime = HandshakeMessage.GetTime();
         int nowtimelast = Integer.parseInt(nowtime.substring(nowtime.length()-1));
         System.out.println("nowtime"+ nowtime);
         System.out.println("timeStampReceived"+ timeStampReceived);
         //hash campare
        if(Arrays.equals(clientDigest.digest(),hashbytesDecrypted)) {
            hashcompare=1;
            Logger.log("Signature verified succeed.");
        }
        //time compare
        if (timeStampReceivedlast-2 < nowtimelast && timeStampReceivedlast+2 >nowtimelast ) { //second is right
                if (timeStampReceived.substring(0,timeStampReceived.length()-2).equals(nowtime.substring(0,nowtime.length()-2))== false){
                    timestampcompare=0;
                    Logger.log("Timestamps are not the same!");
            }
        }else {
            throw new Exception("Timestamp verification failed");
        }
        if(timestampcompare==1 && hashcompare== 1) {
         Logger.log("ClientFinishMessage verified succeed.");
        }
        Logger.log("ClientFinishMessage verified finish.");
    }
    /*the ForwardServer proceeds by sending a ServerFinish message with the hash of the ServerHello and Session messages,
    and the encrypted current timestamp at the ForwardServer.
     */

    public void send_ServerFinish(HandshakeMessage serverhellomsg, HandshakeMessage sessionmsg,String privateKeyFile,Socket socket) throws IOException {
        String flag = "ServerFinish";
        HandshakeMessage serverFinishMessage = new HandshakeMessage();
        String serverhellomsgType = serverhellomsg.getParameter("MessageType");
        String serverhellomsgCertificate = serverhellomsg.getParameter("Certificate");
        String sessionmsgType = sessionmsg.getParameter("MessageType");
        String sessionmsgTargetHost = sessionmsg.getParameter("TargetHost");
        String sessionmsgTargetPort = sessionmsg.getParameter("TargetPort");
        try {
            MessageDigest serverDigest = MessageDigest.getInstance("SHA-256") ;
            serverhellomsg.updateDigest(serverDigest);
            sessionmsg.updateDigest(serverDigest);
            ByteArrayOutputStream byteOutputStream = new ByteArrayOutputStream();
            StringBuilder svmsgbulider = new StringBuilder().append(serverhellomsgType).append(serverhellomsgCertificate).append(sessionmsgType).append(sessionmsgTargetHost).append(sessionmsgTargetPort);
            String svmsg = svmsgbulider.toString();
            //hash
            serverFinishMessage.storeToXML(byteOutputStream, svmsg);
            byte[] bytes = byteOutputStream.toByteArray();
            String str = new String(bytes);
            byte[] hashbytes = serverDigest.digest();
            //Read time
            String time = HandshakeMessage.GetTime();
            byte[] timebytes = time.getBytes(StandardCharsets.UTF_8);
            //private key encrypt and convert to ASCII
            PrivateKey serverPrivateKey = HandshakeCrypto.getPrivateKeyFromKeyFile(privateKeyFile);
            byte[] hashbytesEncrypted = HandshakeCrypto.encrypt(hashbytes, serverPrivateKey);
            byte[] timebytesEncrypted = HandshakeCrypto.encrypt(timebytes, serverPrivateKey);
            String serverFinishMessageEncrypted = Base64.getEncoder().encodeToString(hashbytesEncrypted);//byte to Base64
            String timestampEncrypted = Base64.getEncoder().encodeToString(timebytesEncrypted);
            serverFinishMessage.putParameter("MessageType", "ServerFinished");
            serverFinishMessage.putParameter("Signature", serverFinishMessageEncrypted);
            serverFinishMessage.putParameter("TimeStamp", timestampEncrypted);
            //send Message
            serverFinishMessage.send(socket);
            Logger.log(flag + " message sent.");
        } catch (IllegalBlockSizeException | NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeySpecException | BadPaddingException | InvalidKeyException e) {
            e.printStackTrace();
        }
    }


        public byte[] getSessionKey(){
        return sessionKey;
    }

    public byte[] getSessionIV(){
        return sessionIV;
    }
}