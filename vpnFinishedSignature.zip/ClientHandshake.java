import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.io.ByteArrayOutputStream;
import java.net.Socket;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.cert.*;
import java.security.spec.InvalidKeySpecException;
import java.util.Arrays;
import java.util.Base64;

public class ClientHandshake {
    /*
     * The parameters below should be learned by the client
     * through the handshake protocol.
     */

    /* Session host/port  */
    public String sessionHost;
    public int sessionPort;
    /* Security parameters key/iv should also go here. Fill in! */
    public byte[] sessionKey;
    public byte[] sessionIV;
    public String sessionPortstr;
    private X509Certificate serverCertificate;
    private String serverCertificateString;
    HandshakeMessage sessionMessage;
    HandshakeMessage serverHelloMessage;

    /**
     * Run client handshake protocol on a handshake socket. 
     * Here, we do nothing, for now. 
     */
    public ClientHandshake(Socket handshakeSocket) throws IOException {
    }

    public ClientHandshake(Socket handshakeSocket,String targethost,String targetport,String cacert,String usercert,String ClientPrivateKeyFile) throws Exception {
        HandshakeMessage clientHellomsg = send_clientHello(handshakeSocket, usercert);
        receive_ServerHello(handshakeSocket, cacert);
        HandshakeMessage clientForwardmsg = forward_Client(handshakeSocket, targethost, targetport);
        receive_Serversession(handshakeSocket, ClientPrivateKeyFile);
        //responds with a ClientFinish message
        send_ClientFinish(clientHellomsg,clientForwardmsg,ClientPrivateKeyFile,handshakeSocket);
        receive_ServerFinish(handshakeSocket,cacert);
    }

    public HandshakeMessage send_clientHello(Socket socket, String certificatePath){
        String flag = "ClientHello";
        HandshakeMessage clientHelloMessage = new HandshakeMessage();
        try {
            X509Certificate clientCertificate = VerifyCertificate.readCertificate(certificatePath);
            String clientCertificateString = VerifyCertificate.encodeCertificate(clientCertificate);
            clientHelloMessage.putParameter("MessageType","ClientHello");
            clientHelloMessage.putParameter("Certificate",clientCertificateString);
            clientHelloMessage.send(socket);
            Logger.log(flag + " message sent.");
        } catch (IOException e) {
            e.printStackTrace();
            Logger.log("Error in hello message.");
        } catch (CertificateEncodingException e) {
            e.printStackTrace();
            Logger.log("Error in certificate verification.");
        } catch (CertificateException e) {
            e.printStackTrace();
            Logger.log("Error in certificate encode.");
        }
        return clientHelloMessage;
    }

    public void receive_ServerHello(Socket socket, String caPath) {
        serverHelloMessage = new HandshakeMessage();
        String flag = "ServerHello";
        try {
            serverHelloMessage.recv(socket);
            if (serverHelloMessage.getParameter("MessageType").equals("ServerHello")) {
                serverCertificateString = serverHelloMessage.getParameter("Certificate");
                serverCertificate = VerifyCertificate.decodeCertificate(serverCertificateString);
                X509Certificate caCertificate = VerifyCertificate.readCertificate(caPath);
                VerifyCertificate.verifyCertificate(caCertificate, serverCertificate); //Ensure the validation
                Logger.log("Server certificate verified.");
            } else {
                throw new Exception();
            }
        } catch (IOException e) {
            e.printStackTrace();
            Logger.log("Error in" + flag +"message.");
        } catch (CertificateException e) {
            e.printStackTrace();
            Logger.log("Error in certificate decode.");
        } catch (Exception e) {
            e.printStackTrace();
            Logger.log("Error in certificate verification");
        }
    }


    public HandshakeMessage forward_Client(Socket socket, String targetHost, String targetPort) throws IOException {
        HandshakeMessage clientforwardMessage = new HandshakeMessage();
        clientforwardMessage.putParameter("MessageType","Forward");
        clientforwardMessage.putParameter("TargetHost",targetHost);
        clientforwardMessage.putParameter("TargetPort",targetPort);
        clientforwardMessage.send(socket);
        Logger.log("Forward message sent.");
        return clientforwardMessage;
    }

    public void receive_Serversession(Socket socket, String privateKeyFile) {
        sessionMessage = new HandshakeMessage();
        try {
            sessionMessage.recv(socket);
            if (sessionMessage.getParameter("MessageType").equals("Session")) {
                PrivateKey clientPrivateKey = HandshakeCrypto.getPrivateKeyFromKeyFile(privateKeyFile);
                sessionKey = HandshakeCrypto.decrypt(Base64.getDecoder().decode(sessionMessage.getParameter("SessionKey")), clientPrivateKey);
                sessionIV = HandshakeCrypto.decrypt(Base64.getDecoder().decode(sessionMessage.getParameter("SessionIV")), clientPrivateKey);
                sessionHost = sessionMessage.getParameter("SessionHost");
                sessionPortstr = sessionMessage.getParameter("SessionPort");
                sessionPort = Integer.parseInt(sessionMessage.getParameter("SessionPort"));
                Logger.log("Session message received.");
        } else throw new Exception();
        } catch (IOException e) {
            e.printStackTrace();
            Logger.log("Error in sessionClient message.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /*ForwardClient goes first: when it has received the Session message,
 it responds with a ClientFinish message containing the hash of the ClientHello and Forward messages,
 as well as the current time encrypted.
 Both are encrypted with ForwardClient's private key.
  */
    public void send_ClientFinish(HandshakeMessage clienthellomsg, HandshakeMessage forwardmsg,String privateKeyFile,Socket socket) throws IOException {
        String flag = "ClientFinish";
        HandshakeMessage clientFinishMessage = new HandshakeMessage();

        try {
            ByteArrayOutputStream byteOutputStream = new ByteArrayOutputStream();
            //hash
            MessageDigest clientDigest = MessageDigest.getInstance("SHA-256") ;
            clienthellomsg.updateDigest(clientDigest);
            forwardmsg.updateDigest(clientDigest);
            byte[] hashbytes = clientDigest.digest();
            //Read time
            String time = HandshakeMessage.GetTime();
            byte[] timebytes = time.getBytes(StandardCharsets.UTF_8);
            //private key encrypt and convert to ASCII
            PrivateKey clientPrivateKey = HandshakeCrypto.getPrivateKeyFromKeyFile(privateKeyFile);
            byte[] hashbytesEncrypted = HandshakeCrypto.encrypt(hashbytes, clientPrivateKey);
            byte[] timebytesEncrypted = HandshakeCrypto.encrypt(timebytes, clientPrivateKey);
            String clientFinishMessageEncrypted = Base64.getEncoder().encodeToString(hashbytesEncrypted);//byte to Base64
            String timestampEncrypted = Base64.getEncoder().encodeToString(timebytesEncrypted);
            clientFinishMessage.putParameter("MessageType", "ClientFinished");
            clientFinishMessage.putParameter("Signature", clientFinishMessageEncrypted);
            clientFinishMessage.putParameter("TimeStamp", timestampEncrypted);
            //send Message
            clientFinishMessage.send(socket);
            Logger.log(flag + " message sent.");
        } catch (NoSuchAlgorithmException | InvalidKeySpecException | InvalidKeyException | IllegalBlockSizeException | BadPaddingException | NoSuchPaddingException e) {
            e.printStackTrace();
        }

    }

/*The ForwardClient verifies the FinishSignature in the same way,
and if the verification is successful, the session is established and communication can proceed.
 */
    public void receive_ServerFinish(Socket socket, String certificatefile) throws Exception {
        HandshakeMessage serverFinishMessage = new HandshakeMessage();
        int hashcompare=0;
        int timestampcompare=1;
        serverFinishMessage.recv(socket);
        Logger.log("ServerFinishMessage received.");
        PublicKey serverPublickey = serverCertificate.getPublicKey();
        if (!serverFinishMessage.getParameter("MessageType").equals("ServerFinished")) {
            throw new Exception("Did not receive ServerFinishedMessage.");
        }
        byte[] hashbytesDecrypted = HandshakeCrypto.decrypt(Base64.getDecoder().decode(serverFinishMessage.getParameter("Signature")), serverPublickey);
        byte[] timebyteDecrypted  =  HandshakeCrypto.decrypt(Base64.getDecoder().decode(serverFinishMessage.getParameter("TimeStamp")), serverPublickey);
        String serverhellomsgType="ServerHello";
        String serverhellomsgCertificate= serverCertificateString;
        String sessionmsgType ="Session";
        String sessionmsgTargetHost = sessionHost;
        String sessionmsgTargetPort = sessionPortstr;
        /* compare hash and timestamp */
        ByteArrayOutputStream byteOutputStream = new ByteArrayOutputStream();
        StringBuilder svmsgbulider = new StringBuilder().append(serverhellomsgType).append(serverhellomsgCertificate).append(sessionmsgType).append(sessionmsgTargetHost).append(sessionmsgTargetPort);
        String svmsg = svmsgbulider.toString();
        serverFinishMessage.storeToXML(byteOutputStream, svmsg);
        //get received time
        String timeStampReceived = new String(timebyteDecrypted,"UTF-8");
        int timeStampReceivedlast = Integer.parseInt(timeStampReceived.substring(timeStampReceived.length()-1));
        //get now time
        String nowtime = HandshakeMessage.GetTime();
        int nowtimelast = Integer.parseInt(nowtime.substring(nowtime.length()-1));
        System.out.println("nowtime"+ nowtime);
        System.out.println("timeStampReceived"+ timeStampReceived);
        //compare hash
        MessageDigest serverDigest = MessageDigest.getInstance("SHA-256") ;
        serverHelloMessage.updateDigest(serverDigest);
        sessionMessage.updateDigest(serverDigest);
        if(Arrays.equals(serverDigest.digest(),hashbytesDecrypted)) {
            hashcompare=1;
            Logger.log("Signature verified succeed.");
        }
        //compare timestamp
        if (timeStampReceivedlast-2 < nowtimelast && timeStampReceivedlast+2 >nowtimelast ) { //second is right
            if (timeStampReceived.substring(0,timeStampReceived.length()-2).equals(nowtime.substring(0,nowtime.length()-2))== false){
                timestampcompare=0;
                Logger.log("Timestamps are not the same!");
            }
        }else {
            throw new Exception("Timestamp verification failed");
        }
        if(timestampcompare==1 && hashcompare== 1) {
            Logger.log("ServerFinishMessage verified succeed.");
            Logger.log("Client handshake finished!");
        }
        Logger.log("ServerFinishMessage verified finish.");
    }


    public byte[] getSessionKey() {
        return sessionKey;
    }

    public byte[] getSessionIV() {
        return sessionIV;
    }
}